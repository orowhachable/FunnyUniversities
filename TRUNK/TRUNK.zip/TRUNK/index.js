$(document).ready(function(){
	$().()
});
